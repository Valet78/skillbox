#pragma once

#include <iostream>
#include <map>

// Функции
std::wstring inputText(std::wstring);                // Ввод текста и проверка на пустую строку
bool checkStrings(std::wstring &, std::wstring &);   // Проверка слов